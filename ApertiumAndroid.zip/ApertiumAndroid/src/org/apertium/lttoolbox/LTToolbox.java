/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.apertium.lttoolbox;

import org.apertium.CommandLineInterface;

/**
 * Moved to CommandLineInterface. This class is to be retained until medio 2010 to
 * ensure backwards compatibility.
 * @author Jacob Nordfalk
 */
public class LTToolbox {
  public static void main(String[] argv) throws Exception {
    CommandLineInterface.main(argv);
  }

}
