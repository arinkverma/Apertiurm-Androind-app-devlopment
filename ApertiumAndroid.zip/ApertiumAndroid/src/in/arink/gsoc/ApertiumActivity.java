package in.arink.gsoc;

import org.apertium.port.Port;

import android.app.Activity;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.app.ProgressDialog;
import android.os.Handler;
import android.os.Message;

import java.io.*;

public class ApertiumActivity extends Activity implements OnClickListener, Runnable {

	private static final String[] MODE = {"eo-en","en-eo"};
	private static int DEFAULTMODE = 0;
	private String outputText = null;
	private EditText _inputText;
	private Button _submitButton,_modeButton;
	private TextView _outputText;
	private ProgressDialog progressDialog;



	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		progressDialog = ProgressDialog.show(this, "", "Installing language pair...");
		if(isInstalled("apertium-eo-en","eo-en")==false){
			InstallLanguage("apertium-eo-en","eo-en");
		}
		progressDialog.dismiss();
		initView();
		_submitButton.setOnClickListener(this);
		_modeButton.setOnClickListener(this);
	}
	
	public boolean onCreateOptionsMenu(Menu menu) {
	      MenuInflater inflater = getMenuInflater();
	      inflater.inflate(R.menu.menu, menu);
	      return true;
	 }
	
	public boolean onOptionsItemSelected(MenuItem item) {
	      switch (item.getItemId()) {
	      case R.id.create_new:
	    	  	InstallLanguage("apertium-eo-en","eo-en");
	            Toast.makeText(this, "The default EN-EO language pair have been installed ",Toast.LENGTH_SHORT).show();
	            return true;
	      default:
	            return super.onOptionsItemSelected(item);
	      }
	}

	private void initView() {
		setContentView(R.layout.main);
		_inputText = (EditText) findViewById(R.id.inputtext);
		_submitButton = (Button) findViewById(R.id.submit);
		_outputText = (TextView) findViewById(R.id.outputtext);
		_modeButton = (Button) findViewById(R.id.button1);
		_modeButton.setText(MODE[DEFAULTMODE]);
		
	}

	@Override
	public void onClick(View v) {
		if (v.equals(_submitButton)){
			
			progressDialog = ProgressDialog.show(this, "", "Working..",  true,false);

			Thread thread = new Thread(this);
			thread.start();
		}else if(v.equals(_modeButton)){
			 Toast.makeText(this, "EN-EO mode is under construction",Toast.LENGTH_SHORT).show();	           
			/*if(DEFAULTMODE == 0) DEFAULTMODE = 1;
			else DEFAULTMODE = 0;
			_modeButton.setText(MODE[DEFAULTMODE]);	*/		
		}
	}
	
	
	 public void run() {
		 String inputText = _inputText.getText().toString();		 
		 if (!TextUtils.isEmpty(inputText)) {
				try {
					Port.setAddresss("/sdcard/apertium/apertium-eo-en");
					outputText = Port.get(_inputText.getText().toString(), MODE[DEFAULTMODE]);					
				} catch (Exception e) {
					Log.e("error", e.getMessage());
				}
			}
		 handler.sendEmptyMessage(0);

	 }
	 
	 private Handler handler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				 
				 progressDialog.dismiss();
				 _outputText.setText(outputText);

			}
	};
	
	
	/** To copy data files on sdcard */
	private boolean isInstalled(String path,String pair){
		String extStorageDirectory = Environment.getExternalStorageDirectory().toString();
		File langDirmode = new File(extStorageDirectory +"/apertium/apertium-"+pair+"/modes");
		if(!langDirmode.exists()){
			return false;
		}
		return true;		
		
	}
	
	private void InstallLanguage(String path,String pair) {
	    AssetManager assetManager = getAssets();
	    String[] files = null;	    
	    String newFolder = "/apertium-"+pair;
	    String extStorageDirectory = Environment.getExternalStorageDirectory().toString();
	    File baseDir = new File(extStorageDirectory +"/apertium");
	    File langDir = new File(extStorageDirectory +"/apertium/"+ newFolder);
	    File langDirmode = new File(extStorageDirectory +"/apertium/"+newFolder+"/modes");
	    if(!baseDir.exists()){
	    	baseDir.mkdir();	
	    	langDir.mkdir();
	    	langDirmode.mkdir();
	    }else if(!langDir.exists()){
	    	langDir.mkdir();	    	
	    	langDirmode.mkdir();
	    }else if(!langDirmode.exists()){
	    	langDirmode.mkdir();
	    }
	    
	    try {
	        files = assetManager.list(path);
	    } catch (IOException e) {
	        Log.e("tag1", e.getMessage());
	    }
	    for(String filename : files) {
	        InputStream in = null;
	        OutputStream out = null;
	        try {
	          in = assetManager.open(path+"/"+filename);
	          out = new FileOutputStream(Environment.getExternalStorageDirectory().toString()+"/apertium/"+newFolder+"/" + filename);
	          copyFile(in, out);
	          in.close();
	          in = null;
	          out.flush();
	          out.close();
	          out = null;
	        } catch(Exception e) {
	            Log.e("tag2", e.getMessage());
	        }       
	    }
	    
	    
	    InputStream in = null;
	    OutputStream out = null;
        try {
	          in = assetManager.open(path+"/eo-en.mode");
	          out = new FileOutputStream(Environment.getExternalStorageDirectory().toString()+"/apertium/"+newFolder+"/modes/eo-en.mode");
	          copyFile(in, out);
	          in.close();
	          in = null;
	          out.flush();
	          out.close();
	          in = assetManager.open(path+"/en-eo.mode");
	          out = new FileOutputStream(Environment.getExternalStorageDirectory().toString()+"/apertium/"+newFolder+"/modes/en-eo.mode");
	          copyFile(in, out);
	          in.close();
	          in = null;
	          out.flush();
	          out.close();
	          out = null;
	        } catch(Exception e) {
	            Log.e("tag2", e.getMessage());
	        } 
	}
	
	private void copyFile(InputStream in, OutputStream out) throws IOException {
	    byte[] buffer = new byte[1024];
	    int read;
	    while((read = in.read(buffer)) != -1){
	      out.write(buffer, 0, read);
	    }
	}
	


}