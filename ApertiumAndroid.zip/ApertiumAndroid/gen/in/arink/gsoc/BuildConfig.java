/** Automatically generated file. DO NOT MODIFY */
package in.arink.gsoc;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}